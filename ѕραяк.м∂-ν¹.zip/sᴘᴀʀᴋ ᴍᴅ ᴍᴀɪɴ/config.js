global.bankname = "Opay"
global.banknumber = "7045989058"
global.bankowner = "ᴀsᴋ ғᴏʀ ɴᴀᴍᴇ"
//==========  CPANEL COMMAND ===============\\
global.domain = 'https://queenstech.anonymoushosting.com.ng' // Fill in your domain, don't put a / at the end of the link
global.apikey = 'ptla_lPDiNBSpqCQ9ctLs7qh5MCqfp0QYnJ9ehuOMQxMNqnm' // Fill Apikey
global.capikey = 'ptlc_qHq1Jq1xrnhv7v95n65tNsM7awsHJYyj0NJ3yd0VNKt' // Fill Apikey
//=========================================================//
//Server create panel egg pm2
global.apikey2 = 'ptla_lPDiNBSpqCQ9ctLs7qh5MCqfp0QYnJ9ehuOMQxMNqnm' // Fill Apikey
global.capikey2 = 'ptlc_qHq1Jq1xrnhv7v95n65tNsM7awsHJYyj0NJ3yd0VNKt' // Fill Apikey
global.domain2 = 'https://queenstech.anonymoushosting.com.ng' // Fill Domain
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //don't change it

global.eggsnya2 = '15' // ID of eggs used
global.location2 = '1' // id location
//===========================//
global.eggsnya = '15' // ID of eggs used
global.location3 = '1' // id location
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""